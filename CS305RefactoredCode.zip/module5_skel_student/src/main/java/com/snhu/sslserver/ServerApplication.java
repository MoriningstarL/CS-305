package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest; // Import for hash function

@SpringBootApplication
public class ServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }
}

@RestController
class ServerController {
    @RequestMapping("/hash")
    public String myHash() {
        String data = "Bradly Van Hoorebeke";
        
        try {
            // Create a MessageDigest object with SHA-256 algorithm
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            
            // Calculate the hash value for the data string
            byte[] hashBytes = digest.digest(data.getBytes());
            
            // Convert the hashBytes to a hexadecimal representation
            StringBuilder hexString = new StringBuilder();
            for (byte hashByte : hashBytes) {
                String hex = Integer.toHexString(0xff & hashByte);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            // Return the data string, algorithm used, and the checksum (hash) value
            return "<p>Data: " + data + "<br>Algorithm: SHA-256<br>Checksum: " + hexString.toString() + "</p>";
        } catch (Exception e) {
            // Handle any exceptions, such as NoSuchAlgorithmException
            return "Error: " + e.getMessage();
        }
    }
}

